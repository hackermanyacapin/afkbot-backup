# aternos-afkbot
Hi, this is a aternos bot which stays afk in your minecraft server.
A full setup guide is a available at: https://docs.krushna.me so kindly refer to this as the setup below doesn't include hosting.
#setup
First of all you need to change the ip in [config file](https://github.com/krushna06/afk-bot-for-aternos/blob/main/config.json).
Don't change the port, you may change the rest of the stuff
```
{
	"ip":"yourip.aternos.me",
	"port": "25565",
	"name": "afk bot"
}

```
Then you need to clone this bot to [Replit](https://replit.com/~)
Then in console type ```npm install``` after doing this in console type ```node index.js```
If everything goes correct, this is what you should see in the console


![image](https://user-images.githubusercontent.com/69315835/128631156-f5e257dd-4748-477c-87f1-d627c853590f.png)


#Extra help
If you are facing any issue then you can join this discord server
https://discord.gg/et67UY5J5C

*THANK YOU!! :)*
